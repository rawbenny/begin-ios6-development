//
//  BIDDisclosureDetailViewController.h
//  Nav
//

#import <UIKit/UIKit.h>

@interface BIDDisclosureDetailViewController : UIViewController

@property (weak, readonly, nonatomic) UILabel *label;
@property (copy, nonatomic) NSString *message;

@end
