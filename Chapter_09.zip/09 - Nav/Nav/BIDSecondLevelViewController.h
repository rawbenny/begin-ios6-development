//
//  BIDSecondLevelViewController.h
//  Nav
//

#import <UIKit/UIKit.h>

@interface BIDSecondLevelViewController : UITableViewController

@property (strong, nonatomic) UIImage *rowImage;

@end
