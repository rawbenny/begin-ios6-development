//
//  BIDDeleteMeViewController.h
//  Nav
//

#import "BIDSecondLevelViewController.h"

@interface BIDDeleteMeViewController : BIDSecondLevelViewController

@property (strong, nonatomic) NSMutableArray *computers;

@end
